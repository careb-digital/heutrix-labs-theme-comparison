# Website policies

Store only approved public versions of privacy notices, collection notices, terms and disclaimers here. Draft copy may remain with the website copy pack while it is being reconciled.

The published policy must match the actual form destination, CRM, analytics, cookies/consent, retention, contact point and third-party providers.
