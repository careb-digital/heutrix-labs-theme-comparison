from __future__ import annotations

import html
import io
import subprocess
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
WORD_DIR = ROOT / "Word"
PDF_DIR = ROOT / "PDF"
HTML_DIR = ROOT / "tmp" / "html"
CHROME = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")

PDF_DIR.mkdir(parents=True, exist_ok=True)
HTML_DIR.mkdir(parents=True, exist_ok=True)


def iter_blocks(doc):
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, doc._body)
        elif child.tag == qn("w:tbl"):
            yield Table(child, doc._body)


def paragraph_has_page_break(paragraph: Paragraph) -> bool:
    for br in paragraph._p.iter(qn("w:br")):
        if br.get(qn("w:type")) == "page":
            return True
    return False


def num_kind(doc: Document, paragraph: Paragraph) -> str | None:
    ppr = paragraph._p.pPr
    if ppr is None or ppr.numPr is None or ppr.numPr.numId is None:
        return None
    num_id = ppr.numPr.numId.val
    numbering = doc.part.numbering_part.element
    num = next((n for n in numbering.findall(qn("w:num")) if n.get(qn("w:numId")) == str(num_id)), None)
    if num is None:
        return "ul"
    ref = num.find(qn("w:abstractNumId"))
    if ref is None:
        return "ul"
    abstract_id = ref.get(qn("w:val"))
    abstract = next((a for a in numbering.findall(qn("w:abstractNum")) if a.get(qn("w:abstractNumId")) == abstract_id), None)
    if abstract is None:
        return "ul"
    fmt = abstract.find(".//" + qn("w:numFmt"))
    return "ul" if fmt is None or fmt.get(qn("w:val")) == "bullet" else "ol"


def run_html(run) -> str:
    text = html.escape(run.text).replace("\n", "<br>")
    if not text:
        return ""
    if run.bold:
        text = f"<strong>{text}</strong>"
    if run.italic:
        text = f"<em>{text}</em>"
    if run.underline:
        text = f"<u>{text}</u>"
    color = None
    if run.font.color is not None and run.font.color.rgb is not None:
        color = str(run.font.color.rgb)
    size = run.font.size.pt if run.font.size is not None else None
    styles = []
    if color:
        styles.append(f"color:#{color}")
    if size:
        styles.append(f"font-size:{size:.1f}pt")
    if styles:
        text = f'<span style="{";".join(styles)}">{text}</span>'
    return text


def paragraph_html(paragraph: Paragraph) -> tuple[str, str | None]:
    text = "".join(run_html(run) for run in paragraph.runs)
    if not text and paragraph.text:
        text = html.escape(paragraph.text)
    if paragraph_has_page_break(paragraph):
        return '<div class="page-break"></div>', None
    style_name = paragraph.style.name if paragraph.style is not None else ""
    list_kind = num_kind(paragraph.part.document, paragraph)
    if list_kind:
        return f"<li>{text}</li>", list_kind
    if style_name == "Heading 1":
        return f"<h1>{text}</h1>", None
    if style_name == "Heading 2":
        return f"<h2>{text}</h2>", None
    if style_name == "Heading 3":
        return f"<h3>{text}</h3>", None
    max_size = max((run.font.size.pt for run in paragraph.runs if run.font.size is not None), default=0)
    all_bold = any(run.bold for run in paragraph.runs)
    plain = paragraph.text.strip()
    if max_size >= 24:
        return f'<p class="title">{text}</p>', None
    if 12.5 <= max_size < 20:
        return f'<p class="subtitle">{text}</p>', None
    if max_size <= 9.5 and all_bold and plain and plain.upper() == plain:
        return f'<p class="kicker">{text}</p>', None
    if not text:
        return '<p class="blank">&nbsp;</p>', None
    if "http://" in paragraph.text or "https://" in paragraph.text:
        return f'<p class="source">{text}</p>', None
    return f"<p>{text}</p>", None


def cell_fill(cell) -> str | None:
    tcpr = cell._tc.tcPr
    if tcpr is None:
        return None
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        return None
    fill = shd.get(qn("w:fill"))
    return fill if fill and fill not in ("auto", "none") else None


def table_html(table: Table) -> str:
    rows = []
    for r_idx, row in enumerate(table.rows):
        cells = []
        for cell in row.cells:
            content = []
            for p in cell.paragraphs:
                rendered, _ = paragraph_html(p)
                content.append(rendered)
            fill = cell_fill(cell)
            style = f' style="background:#{fill}"' if fill else ""
            tag = "th" if r_idx == 0 and fill in ("17324D", "2E74B5") else "td"
            cells.append(f"<{tag}{style}>{''.join(content)}</{tag}>")
        rows.append(f"<tr>{''.join(cells)}</tr>")
    if rows and "<th" in rows[0]:
        return f"<table><thead>{rows[0]}</thead><tbody>{''.join(rows[1:])}</tbody></table>"
    return f"<table><tbody>{''.join(rows)}</tbody></table>"


def build_html(docx_path: Path) -> str:
    doc = Document(docx_path)
    fragments = []
    open_list = None
    for block in iter_blocks(doc):
        if isinstance(block, Paragraph):
            rendered, list_kind = paragraph_html(block)
            if list_kind:
                if open_list != list_kind:
                    if open_list:
                        fragments.append(f"</{open_list}>")
                    fragments.append(f"<{list_kind}>")
                    open_list = list_kind
                fragments.append(rendered)
            else:
                if open_list:
                    fragments.append(f"</{open_list}>")
                    open_list = None
                fragments.append(rendered)
        else:
            if open_list:
                fragments.append(f"</{open_list}>")
                open_list = None
            fragments.append(table_html(block))
    if open_list:
        fragments.append(f"</{open_list}>")

    display_title = html.escape(docx_path.stem.replace("_", " "))
    css = r"""
@page { size: Letter; margin: 0.72in 0.82in 0.72in 0.82in; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; line-height: 1.10; color: #20262E; }
p { margin: 0 0 6pt 0; orphans: 3; widows: 3; }
p.source { margin: 0 0 3pt 0; font-size: 8.8pt; line-height: 1.05; }
p.blank { margin: 0 0 2pt 0; font-size: 2pt; }
p.title { margin: 0 0 6pt 0; color: #17324D; font-size: 28pt !important; line-height: 1.04; font-weight: 700; }
p.subtitle { margin: 0 0 16pt 0; color: #66717E; font-size: 13pt !important; line-height: 1.15; }
p.kicker { margin: 8pt 0 2pt 0; color: #2E74B5; font-size: 9pt !important; font-weight: 700; text-transform: uppercase; letter-spacing: 0.03em; }
h1 { margin: 16pt 0 8pt 0; color: #2E74B5; font-size: 16pt; line-height: 1.0; page-break-after: avoid; }
h2 { margin: 12pt 0 6pt 0; color: #2E74B5; font-size: 13pt; line-height: 1.0; page-break-after: avoid; }
h3 { margin: 8pt 0 4pt 0; color: #1F4D78; font-size: 12pt; line-height: 1.0; page-break-after: avoid; }
ul, ol { margin: 0 0 6pt 0; padding-left: 0.52in; }
li { margin: 0 0 8pt 0; padding-left: 0.02in; page-break-inside: avoid; }
table { width: 100%; border-collapse: collapse; table-layout: fixed; margin: 4pt 0 10pt 0; font-size: 9.2pt; page-break-inside: auto; }
thead { display: table-header-group; }
tr { page-break-inside: avoid; }
th, td { border: 0.6px solid #C9D2DC; padding: 6pt 7pt; vertical-align: middle; overflow-wrap: anywhere; }
th { color: white; background: #17324D; font-weight: 700; text-align: left; }
td p, th p { margin: 0 0 2pt 0; font-size: inherit; line-height: 1.08; }
td p:last-child, th p:last-child { margin-bottom: 0; }
.page-break { break-before: page; page-break-before: always; }
strong { font-weight: 700; }
"""
    return f"""<!doctype html><html><head><meta charset=\"utf-8\"><title>{display_title}</title><style>{css}</style></head>
<body><main>{''.join(fragments)}</main></body></html>"""


def stamp_footer(pdf_path: Path, display_title: str) -> None:
    reader = PdfReader(str(pdf_path))
    writer = PdfWriter()
    total = len(reader.pages)
    short = display_title.replace("_", " ")
    if len(short) > 54:
        short = short[:51] + "..."
    for index, page in enumerate(reader.pages, start=1):
        width = float(page.mediabox.width)
        height = float(page.mediabox.height)
        packet = io.BytesIO()
        overlay = canvas.Canvas(packet, pagesize=(width, height))
        overlay.setFont("Helvetica", 7.5)
        overlay.setFillColorRGB(0.40, 0.44, 0.49)
        overlay.drawString(59, 20, f"HEUTRIX | {short}")
        overlay.drawCentredString(width / 2, 20, f"Page {index} of {total}")
        overlay.drawRightString(width - 59, 20, "CONFIDENTIAL")
        overlay.save()
        packet.seek(0)
        footer_page = PdfReader(packet).pages[0]
        page.merge_page(footer_page)
        writer.add_page(page)
    temp = pdf_path.with_suffix(".stamped.pdf")
    with temp.open("wb") as handle:
        writer.write(handle)
    temp.replace(pdf_path)


def main() -> None:
    if not CHROME.exists():
        raise SystemExit(f"Chrome not found at {CHROME}")
    for docx_path in sorted(WORD_DIR.glob("*.docx")):
        html_path = HTML_DIR / (docx_path.stem + ".html")
        pdf_path = PDF_DIR / (docx_path.stem + ".pdf")
        html_path.write_text(build_html(docx_path), encoding="utf-8")
        user_data = ROOT / "tmp" / "chrome-profile" / docx_path.stem
        user_data.mkdir(parents=True, exist_ok=True)
        cmd = [
            str(CHROME),
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            f"--user-data-dir={user_data}",
            f"--print-to-pdf={pdf_path}",
            html_path.resolve().as_uri(),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0 or not pdf_path.exists():
            raise RuntimeError(f"Chrome PDF failed for {docx_path.name}: {result.stderr}")
        stamp_footer(pdf_path, docx_path.stem)
        print(pdf_path)


if __name__ == "__main__":
    main()
