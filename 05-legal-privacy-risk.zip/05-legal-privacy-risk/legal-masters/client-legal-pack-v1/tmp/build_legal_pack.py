from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "Word"
OUT.mkdir(parents=True, exist_ok=True)

VERSION = "1.0"
ISSUE_DATE = "1 August 2026"

NAVY = "17324D"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
INK = "20262E"
MUTED = "66717E"
LIGHT_BLUE = "E8EEF5"
LIGHT_GREY = "F2F4F7"
PALE_YELLOW = "FFF4CE"
PALE_RED = "FCE8E6"
WHITE = "FFFFFF"
BORDER = "C9D2DC"


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def set_table_geometry(table, widths_dxa: Sequence[int], indent_dxa: int = 120) -> None:
    total = sum(widths_dxa)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "fixed")

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(total))

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:type"), "dxa")
    tbl_ind.set(qn("w:w"), str(indent_dxa))

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        prevent_row_split(row)
        for idx, cell in enumerate(row.cells):
            width = widths_dxa[min(idx, len(widths_dxa) - 1)]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:type"), "dxa")
            tc_w.set(qn("w:w"), str(width))
            cell.width = Inches(width / 1440)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)


def set_table_borders(table, color=BORDER, size="6") -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def set_repeat_header(row) -> None:
    set_repeat_table_header(row)


def style_cell_text(cell, bold=False, color=INK, size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT) -> None:
    for paragraph in cell.paragraphs:
        paragraph.alignment = align
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.05
        for run in paragraph.runs:
            set_run_font(run, size=size, color=color, bold=bold)


def set_run_font(run, name="Calibri", size=None, color=None, bold=None, italic=None) -> None:
    run.font.name = name
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def add_page_field(paragraph) -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for el in (begin, instr, separate, text, end):
        run._r.append(el)
    set_run_font(run, size=8.5, color=MUTED)


def add_numbering_definition(doc: Document, kind: str) -> int:
    numbering = doc.part.numbering_part.element
    abstract_ids = [int(e.get(qn("w:abstractNumId"))) for e in numbering.findall(qn("w:abstractNum"))]
    num_ids = [int(e.get(qn("w:numId"))) for e in numbering.findall(qn("w:num"))]
    abstract_id = max(abstract_ids, default=0) + 1
    num_id = max(num_ids, default=0) + 1

    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)
    level = OxmlElement("w:lvl")
    level.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    level.append(start)
    fmt = OxmlElement("w:numFmt")
    fmt.set(qn("w:val"), "bullet" if kind == "bullet" else "decimal")
    level.append(fmt)
    text = OxmlElement("w:lvlText")
    text.set(qn("w:val"), "•" if kind == "bullet" else "%1.")
    level.append(text)
    jc = OxmlElement("w:lvlJc")
    jc.set(qn("w:val"), "left")
    level.append(jc)
    ppr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "720")
    tabs.append(tab)
    ppr.append(tabs)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:left"), "720")
    ind.set(qn("w:hanging"), "360")
    ppr.append(ind)
    level.append(ppr)
    rpr = OxmlElement("w:rPr")
    fonts = OxmlElement("w:rFonts")
    fonts.set(qn("w:ascii"), "Calibri")
    fonts.set(qn("w:hAnsi"), "Calibri")
    rpr.append(fonts)
    level.append(rpr)
    abstract.append(level)
    first_num_index = next(
        (index for index, child in enumerate(numbering) if child.tag == qn("w:num")),
        len(numbering),
    )
    numbering.insert(first_num_index, abstract)

    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    ref = OxmlElement("w:abstractNumId")
    ref.set(qn("w:val"), str(abstract_id))
    num.append(ref)
    numbering.append(num)
    return num_id


def apply_num(paragraph, num_id: int) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = p_pr.find(qn("w:numPr"))
    if num_pr is None:
        num_pr = OxmlElement("w:numPr")
        p_pr.append(num_pr)
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num = OxmlElement("w:numId")
    num.set(qn("w:val"), str(num_id))
    num_pr.append(ilvl)
    num_pr.append(num)


def configure_document(doc: Document, short_title: str) -> dict[str, int]:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal.font.size = Pt(11)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10
    normal.paragraph_format.widow_control = True

    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ):
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.line_spacing = 1.0
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.keep_together = True

    header = section.header
    hp = header.paragraphs[0]
    hp.paragraph_format.space_after = Pt(0)
    hp.paragraph_format.tab_stops.add_tab_stop(Inches(6.5))
    left = hp.add_run(f"HEUTRIX  |  {short_title}")
    set_run_font(left, size=8.5, color=MUTED, bold=True)
    right = hp.add_run("\tCONFIDENTIAL")
    set_run_font(right, size=8.5, color=MUTED, bold=True)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fp.paragraph_format.space_before = Pt(0)
    fp.paragraph_format.space_after = Pt(0)
    run = fp.add_run(f"Heutrix Pty Ltd  |  v{VERSION}  |  ")
    set_run_font(run, size=8.5, color=MUTED)
    add_page_field(fp)

    doc.core_properties.title = short_title
    doc.core_properties.subject = "Heutrix client legal pack"
    doc.core_properties.author = "Heutrix Pty Ltd"
    doc.core_properties.last_modified_by = "Heutrix Pty Ltd"
    doc.core_properties.comments = "Prepared for solicitor review and client use."

    return {
        "bullet": add_numbering_definition(doc, "bullet"),
        "decimal": add_numbering_definition(doc, "decimal"),
    }


def add_kicker(doc, text: str, color=BLUE) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    run = p.add_run(text.upper())
    set_run_font(run, size=9, color=color, bold=True)


def add_title(doc, title: str, subtitle: str | None = None) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(title)
    set_run_font(run, size=28, color=NAVY, bold=True)
    if subtitle:
        p2 = doc.add_paragraph()
        p2.paragraph_format.space_before = Pt(0)
        p2.paragraph_format.space_after = Pt(16)
        run2 = p2.add_run(subtitle)
        set_run_font(run2, size=13, color=MUTED)


def add_metadata(doc, rows: Sequence[tuple[str, str]], alert_rows: set[int] | None = None) -> None:
    alert_rows = alert_rows or set()
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    for idx, (label, value) in enumerate(rows):
        cells = table.add_row().cells
        cells[0].text = label
        cells[1].text = value
        set_cell_shading(cells[0], LIGHT_BLUE)
        if idx in alert_rows:
            set_cell_shading(cells[1], PALE_YELLOW)
        style_cell_text(cells[0], bold=True, color=NAVY, size=9.5)
        style_cell_text(cells[1], size=9.5)
    set_table_geometry(table, [2700, 6660])
    set_table_borders(table)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_callout(doc, label: str, text: str, fill=LIGHT_GREY, label_color=NAVY) -> None:
    table = doc.add_table(rows=1, cols=1)
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    r1 = p.add_run(f"{label}: ")
    set_run_font(r1, size=10, color=label_color, bold=True)
    r2 = p.add_run(text)
    set_run_font(r2, size=10, color=INK)
    set_table_geometry(table, [9360])
    set_table_borders(table, color=fill, size="2")
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def add_heading(doc, text: str, level=1) -> None:
    doc.add_paragraph(text, style=f"Heading {level}")


def add_para(doc, text: str, bold_lead: str | None = None, italic=False) -> None:
    p = doc.add_paragraph()
    if bold_lead and text.startswith(bold_lead):
        r1 = p.add_run(bold_lead)
        set_run_font(r1, bold=True)
        r2 = p.add_run(text[len(bold_lead):])
        set_run_font(r2, italic=italic)
    else:
        r = p.add_run(text)
        set_run_font(r, italic=italic)


def add_bullets(doc, items: Iterable[str], nums: dict[str, int]) -> None:
    for item in items:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(8)
        p.paragraph_format.line_spacing = 1.167
        apply_num(p, nums["bullet"])
        r = p.add_run(item)
        set_run_font(r)


def add_steps(doc, items: Iterable[str], nums: dict[str, int]) -> None:
    for item in items:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(8)
        p.paragraph_format.line_spacing = 1.167
        apply_num(p, nums["decimal"])
        r = p.add_run(item)
        set_run_font(r)


def add_definition(doc, term: str, definition: str) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.18)
    p.paragraph_format.first_line_indent = Inches(-0.18)
    r1 = p.add_run(f"{term}. ")
    set_run_font(r1, bold=True, color=NAVY)
    r2 = p.add_run(definition)
    set_run_font(r2)


def add_signature_block(doc, left_party: str, right_party: str) -> None:
    add_heading(doc, "Signing", 1)
    add_para(doc, "Each signatory confirms that they are authorised to bind the party named below. Signatures may be electronic and in counterparts.")
    table = doc.add_table(rows=6, cols=2)
    fields = [
        (left_party, right_party),
        ("Signature: __________________________", "Signature: __________________________"),
        ("Name: ______________________________", "Name: ______________________________"),
        ("Position: ___________________________", "Position: ___________________________"),
        ("Date: _______________________________", "Date: _______________________________"),
        ("Email for notices: __________________", "Email for notices: __________________"),
    ]
    for row, vals in zip(table.rows, fields):
        for cell, value in zip(row.cells, vals):
            cell.text = value
            if row is table.rows[0]:
                set_cell_shading(cell, LIGHT_BLUE)
                style_cell_text(cell, bold=True, color=NAVY, size=9.5)
            else:
                style_cell_text(cell, size=9.5)
    set_table_geometry(table, [4680, 4680])
    set_table_borders(table)


def add_source(doc, title: str, url: str) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r1 = p.add_run(f"{title}: ")
    set_run_font(r1, size=9.5, bold=True, color=NAVY)
    r2 = p.add_run(url)
    set_run_font(r2, size=9.5, color=DARK_BLUE)


def save(doc: Document, filename: str) -> None:
    path = OUT / filename
    doc.save(path)
    print(path)


def readiness_guide() -> None:
    doc = Document()
    nums = configure_document(doc, "Legal Readiness Guide")
    add_kicker(doc, "Internal issue control")
    add_title(doc, "Client Contract Pack", "Issue and legal-readiness guide")
    add_metadata(doc, [
        ("Owner", "Heutrix Pty Ltd"),
        ("Version", f"{VERSION} | {ISSUE_DATE}"),
        ("Status", "INTERNAL - complete stop-issue items before client signature"),
        ("Jurisdiction basis", "Australia; governing law drafted for Victoria"),
    ], alert_rows={2})
    add_callout(doc, "Important", "This pack is a commercially usable first draft, not a substitute for advice from an Australian solicitor. A solicitor should confirm the entity details, liability settings, privacy status, insurance position and the final service model before first issue.", fill=PALE_YELLOW)

    add_heading(doc, "1. Current launch position", 1)
    add_para(doc, "The pack is designed for Heutrix's confirmed workflow-improvement, practice-visibility, internal-system and safe-AI services for Australian allied health practices and disability support providers. The launch Workflow Diagnostic is set at AUD 950 plus GST, subject to verified GST registration.")
    add_para(doc, "The contracting party used throughout is Heutrix Pty Ltd. No ACN, ABN, registered office, monitored legal/privacy email or insurance schedule was present in the source material.")

    add_heading(doc, "2. Stop-issue items", 1)
    add_callout(doc, "Do not sign yet", "Complete every item below in the Word masters before converting the client-specific issue copy to PDF.", fill=PALE_RED, label_color="9B1C1C")
    stop_rows = [
        ("Entity identity", "Verify the exact ASIC-registered company name and ACN. Place the ACN (or qualifying ABN) on page 1 of every public document."),
        ("ABN and GST", "Confirm an active ABN and GST registration. Do not label invoices 'Tax invoice' or add GST unless registered."),
        ("Addresses", "Insert the registered/service address and the operational contact address for notices."),
        ("Contact channels", "Insert a monitored contracts email and privacy contact path; confirm the live website domain."),
        ("Insurance", "Confirm professional indemnity, public liability and cyber cover, limits, exclusions and retroactive dates. Insert only verified cover in each SOW."),
        ("Approved systems", "Approve the exact Google Workspace or Microsoft 365/SharePoint tenant, applications, administrators, hosting regions and subprocessors."),
        ("Banking and invoices", "Confirm the Heutrix bank account, invoicing platform, payment terms and fraud-resistant bank-detail change process."),
        ("Signing authority", "Confirm who may sign for Heutrix and keep the supporting director/board authority with the contract record."),
    ]
    table = doc.add_table(rows=1, cols=3)
    table.rows[0].cells[0].text = "Item"
    table.rows[0].cells[1].text = "Required action"
    table.rows[0].cells[2].text = "Owner / complete"
    for cell in table.rows[0].cells:
        set_cell_shading(cell, NAVY)
        style_cell_text(cell, bold=True, color=WHITE, size=9)
    set_repeat_header(table.rows[0])
    for item, action in stop_rows:
        cells = table.add_row().cells
        cells[0].text = item
        cells[1].text = action
        cells[2].text = "________________"
        style_cell_text(cells[0], bold=True, color=NAVY, size=9)
        style_cell_text(cells[1], size=9)
        style_cell_text(cells[2], size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_table_geometry(table, [1900, 5660, 1800])
    set_table_borders(table)

    add_heading(doc, "3. Contract map", 1)
    rows = [
        ("Before a fit call", "Privacy collection notice. Use the mutual NDA only if non-public detail must be exchanged before engagement."),
        ("Every paid client", "Signed Client Services Agreement plus a signed Order Form or Statement of Work."),
        ("Workflow Diagnostic", "Use the Workflow Diagnostic Order Form with the Client Services Agreement. Default data setting is de-identified/sample information only."),
        ("Build or system access", "Add a General SOW and an approved Data and System Access Authorisation before access is granted."),
        ("Any AI use", "Complete the AI Use Case Approval. No AI use is approved by silence or by a generic project description."),
        ("Scope change", "Use the Change Request before extra work, fees, tools, data or dates are introduced."),
        ("Project close", "Use Deliverable Review and Acceptance plus Handover and Access Closure."),
        ("Website", "Publish the Privacy Policy, Collection Notice and Website Terms after reconciling them to the live forms, cookies, analytics and vendors."),
    ]
    for label, detail in rows:
        add_definition(doc, label, detail)

    add_heading(doc, "4. Recommended Workflow Diagnostic defaults to ratify", 1)
    add_bullets(doc, [
        "One remote discovery workshop of up to 90 minutes.",
        "Review of up to five relevant documents or 50 pages in total.",
        "One current-state map, one future-state map, a prioritised opportunity list, a findings presentation of up to 60 minutes and a concise written report.",
        "Completion target of 10 business days after payment and receipt of agreed inputs.",
        "Fee paid in advance; unused amounts refunded if Heutrix terminates before performing the relevant services.",
        "No patient, participant, worker or other sensitive information; use synthetic, de-identified or redacted material only.",
    ], nums)

    add_heading(doc, "5. Client issue sequence", 1)
    add_steps(doc, [
        "Check the client legal name, ABN/ACN, authorised signatory and notice email.",
        "Select and complete the SOW, including scope boundaries, acceptance criteria, dates, fees, IP option, insurance and data/AI settings.",
        "Complete the data classification and confirm the approved tenant, storage location, administrators and access end date.",
        "Send the CSA and SOW together. Do not rely on a website link that can change after signature.",
        "Obtain signatures before starting paid work or accessing a client system.",
        "Save the signed documents, approved change requests and access records in the approved Heutrix contract repository.",
        "Invoice using verified entity, ABN and GST particulars.",
        "At close, document acceptance, handover, access removal and data return/deletion.",
    ], nums)

    add_heading(doc, "6. Key legal design decisions", 1)
    add_bullets(doc, [
        "The terms preserve non-excludable Australian Consumer Law rights and use objective acceptance and cure processes.",
        "Termination, suspension and variation rights are reciprocal or tied to defined risks to reduce unfair-contract-term exposure.",
        "The general liability cap and a higher confidentiality/privacy/IP cap are transparent but must be aligned with insurance and risk appetite by a solicitor.",
        "Victorian health-information protections are treated as relevant whenever Heutrix handles identifiable health information in Victoria, regardless of business size.",
        "AI use is not approved by default. Each tool, use case, data category and human reviewer must be recorded.",
        "The privacy policy does not assume that the federal small-business exemption applies; it states that applicable federal and state privacy laws will be followed.",
    ], nums)

    add_heading(doc, "7. Primary legal and regulatory sources checked", 1)
    add_para(doc, f"Source check date: {ISSUE_DATE}. These links are included for solicitor verification and ongoing maintenance.")
    sources = [
        ("ASIC - Australian Company Numbers", "https://asic.gov.au/for-business/registering-a-company/steps-to-register-a-company/australian-company-numbers/"),
        ("Australian Business Register - ABN Lookup", "https://abr.business.gov.au/"),
        ("ACCC - Contracts and unfair terms", "https://www.accc.gov.au/business/selling-products-and-services/contracts"),
        ("ACCC - Consumer rights and guarantees", "https://www.accc.gov.au/business/selling-products-and-services/consumer-rights-and-guarantees"),
        ("OAIC - Small business and the Privacy Act", "https://www.oaic.gov.au/privacy/privacy-guidance-for-organisations-and-government-agencies/organisations/small-business"),
        ("OAIC - APP 1 privacy policy guidance", "https://www.oaic.gov.au/privacy/australian-privacy-principles/australian-privacy-principles-guidelines/chapter-1-app-1-open-and-transparent-management-of-personal-information"),
        ("OAIC - Notifiable Data Breaches", "https://www.oaic.gov.au/privacy/notifiable-data-breaches"),
        ("Victorian Department of Health - Health Records Act", "https://www.health.vic.gov.au/legislation/health-records-act"),
        ("ACMA - Spam compliance", "https://www.acma.gov.au/avoid-sending-spam"),
        ("ATO - Business registration obligations", "https://www.ato.gov.au/businesses-and-organisations/starting-registering-or-closing-a-business/registration-obligations-for-businesses"),
    ]
    for title, url in sources:
        add_source(doc, title, url)

    save(doc, "00_Heutrix_Legal_Readiness_Guide.docx")


def client_services_agreement() -> None:
    doc = Document()
    nums = configure_document(doc, "Client Services Agreement")
    add_kicker(doc, "Master agreement")
    add_title(doc, "Client Services Agreement", "Workflow improvement, practical systems and controlled AI support")
    add_metadata(doc, [
        ("Provider", "Heutrix Pty Ltd"),
        ("Provider ACN / ABN", "________________________________  COMPLETE BEFORE ISSUE"),
        ("Client", "________________________________________________________"),
        ("Agreement date", "________________________________________________________"),
        ("Version", f"{VERSION} | {ISSUE_DATE}"),
    ], alert_rows={1})
    add_callout(doc, "How this agreement works", "This agreement contains the standing terms. Each project starts only when both parties sign an Order Form or Statement of Work (SOW). Data access and AI use must also be expressly approved where relevant.")

    add_heading(doc, "1. Agreement structure", 1)
    add_para(doc, "This Client Services Agreement is between Heutrix Pty Ltd (Heutrix) and the Client identified above. It starts on the Agreement date and applies to every SOW signed under it.")
    add_para(doc, "A SOW may add or change terms for that project. If documents conflict, the order is: the SOW's Special Conditions; the SOW; an expressly activated Data Handling or AI Schedule; this agreement. A purchase order is administrative only and does not amend these terms unless both parties sign the amendment.")
    add_para(doc, "No project begins by implication. A proposal, estimate, workshop discussion or email is not a SOW unless it clearly identifies itself as one and is signed by both parties.")

    add_heading(doc, "2. Definitions", 1)
    defs = [
        ("Acceptance Criteria", "the objective criteria stated in the SOW for determining whether a Deliverable is complete"),
        ("Applicable Privacy Law", "the Privacy Act 1988 (Cth), Australian Privacy Principles, Health Records Act 2001 (Vic), applicable State or Territory health-records laws, and any other privacy, data-protection or breach-notification law binding on a party or the relevant handling"),
        ("Background Materials", "methods, templates, software, know-how, prompts, libraries, processes and other materials developed independently of the SOW or used generally across projects"),
        ("Client Data", "information, records, content, credentials or data made available by or for the Client, including Personal Information"),
        ("Client Materials", "Client Data and all documents, systems, branding, IP and other materials supplied or licensed by the Client"),
        ("Confidential Information", "non-public business, technical, financial, security, personal or operational information disclosed in any form, including the terms of a SOW"),
        ("Deliverable", "an output expressly identified as a deliverable in a SOW"),
        ("Personal Information", "personal information, sensitive information and health information as defined by Applicable Privacy Law"),
        ("Security Incident", "actual or reasonably suspected unauthorised access, disclosure, loss, alteration, destruction or unavailability of Client Data, or compromise of a system used to handle Client Data"),
        ("Services", "the services described in a signed SOW"),
        ("SOW", "an Order Form, Statement of Work or change request signed by both parties under this agreement"),
    ]
    for term, definition in defs:
        add_definition(doc, term, definition)

    add_heading(doc, "3. Services and professional standard", 1)
    add_para(doc, "Heutrix will perform the Services with due care and skill, using appropriately skilled personnel, in accordance with the signed SOW and applicable laws. Heutrix will keep the Client reasonably informed of material progress, assumptions, risks and decisions required from the Client.")
    add_para(doc, "Heutrix may use employees and subcontractors and remains responsible for their performance. A subcontractor may access Personal Information or Client systems only if approved as required by the Data Handling Schedule and bound by written obligations no less protective than the relevant obligations in this agreement.")
    add_para(doc, "Heutrix provides operational workflow, system and controlled AI support. Unless a SOW expressly says otherwise and Heutrix has the required qualified capability, the Services do not include legal, tax, financial, employment, clinical, medical, regulatory, official audit, NDIS registration, compliance assurance or medical-device advice or services.")
    add_para(doc, "Recommendations are based on the information, access and assumptions available at the time. Heutrix does not guarantee cost savings, revenue, productivity, registration, compliance, regulatory approval or other business outcomes.")

    add_heading(doc, "4. Client responsibilities", 1)
    add_bullets(doc, [
        "Give timely, accurate and complete information, decisions, approvals, access and feedback reasonably required for the Services.",
        "Appoint an authorised project owner and appropriate reviewers, including privacy, security, clinical, safeguarding or professional reviewers where relevant.",
        "Ensure it has lawful authority to provide Client Materials and instructions, and that required notices, consents and permissions are in place.",
        "Maintain backups, business continuity, user administration and security for Client-controlled systems unless the SOW expressly allocates a task to Heutrix.",
        "Review Deliverables and all material outputs before operational use, especially where they affect patients, participants, workers, safety, rights, payments, compliance or professional obligations.",
        "Not provide live Personal Information, credentials or production access until the data and access controls required by this agreement and the SOW are approved.",
    ], nums)
    add_para(doc, "Heutrix is not responsible for delay to the extent caused by the Client's failure to meet a dependency. Heutrix must notify the Client promptly, explain the effect and take reasonable steps to minimise avoidable delay.")

    add_heading(doc, "5. Project governance, changes and acceptance", 1)
    add_para(doc, "Each party will nominate a project contact. Project contacts may make day-to-day decisions within the signed scope but cannot change fees, liability, IP ownership, data categories, AI approval or other material terms without a signed change request.")
    add_para(doc, "If either party identifies a scope, timing, cost, data, security or dependency change, Heutrix will document the proposed impact. Neither party must proceed with the changed work until both parties sign the change request, except for reasonable emergency steps needed to protect people, data or systems.")
    add_para(doc, "The Client will review each Deliverable against the Acceptance Criteria within five business days, or another period stated in the SOW. It will accept the Deliverable or provide specific reasons and evidence of non-conformity. Heutrix will correct a material non-conformity within a reasonable agreed period and resubmit it.")
    add_para(doc, "If the Client does not respond within the review period after a reminder, the Deliverable is treated as accepted for project administration and invoicing only. This does not waive latent defects, warranties, consumer guarantees or rights that cannot legally be excluded.")

    add_heading(doc, "6. Fees, GST and payment", 1)
    add_para(doc, "The Client will pay the fees and approved expenses stated in the SOW. Unless the SOW says otherwise, invoices are due within seven calendar days.")
    add_para(doc, "Amounts are exclusive of GST. GST is payable only where Heutrix is registered or required to be registered for GST and issues a valid tax invoice. If an adjustment event occurs, the parties will make the corresponding adjustment after a valid adjustment note.")
    add_para(doc, "The Client may dispute an invoice in good faith by giving reasons within five business days. It must pay the undisputed amount by the due date. The parties will work promptly to resolve the disputed part. Heutrix may recover reasonable external debt-recovery costs caused by an undisputed overdue amount, to the extent permitted by law.")
    add_para(doc, "Heutrix may require an advance payment stated in the SOW. Advance payments are applied to the Services and are not automatically non-refundable. If the agreement or SOW ends, Heutrix will refund any amount paid for Services not performed, less fees for work properly performed and unavoidable third-party costs approved or disclosed in the SOW.")

    add_heading(doc, "7. Intellectual property", 1)
    add_para(doc, "Each party retains ownership of its pre-existing IP and Background Materials. The Client grants Heutrix a limited, non-exclusive licence to use Client Materials only to perform the Services and meet legal obligations.")
    add_para(doc, "The SOW must select the Deliverable IP model. If it does not, the Client owns the project-specific Deliverables on full payment, excluding Heutrix Background Materials and third-party materials. Heutrix assigns to the Client its rights in those project-specific Deliverables on full payment and will sign reasonable documents to confirm the assignment, at the Client's cost if more than administrative.")
    add_para(doc, "Heutrix retains all Background Materials. To the extent Background Materials are embedded in a Client-owned Deliverable, Heutrix grants the Client a perpetual, worldwide, royalty-free, non-exclusive licence to use, copy, modify and have them maintained as part of that Deliverable for the Client's internal business purposes.")
    add_para(doc, "If the SOW selects a Heutrix-licensed solution, the SOW will state the licence scope, users, term, support, portability and exit rights. Neither party may remove ownership notices or use the other party's branding, name, testimonial or case study without prior written consent.")

    add_heading(doc, "8. Third-party products and open-source materials", 1)
    add_para(doc, "A SOW must identify material third-party products, platforms and licence costs known at signing. Third-party terms apply between the Client and the relevant provider where the Client contracts directly. Heutrix will not accept third-party terms for the Client without written authority.")
    add_para(doc, "Heutrix will not knowingly include material subject to a licence that requires disclosure of the Client's proprietary source code or materials without the Client's prior written approval. Heutrix is not responsible for a third-party outage, change or defect outside its reasonable control, but will provide reasonable assistance within the SOW or an approved change request.")

    add_heading(doc, "9. Confidentiality", 1)
    add_para(doc, "The receiving party may use Confidential Information only for the agreement and may disclose it only to personnel, professional advisers and approved subcontractors who need it and are bound by confidentiality obligations. It must protect the information with at least reasonable care and promptly notify the disclosing party of known unauthorised use or disclosure.")
    add_para(doc, "Confidentiality does not apply to information the receiving party can demonstrate was lawfully known without restriction, independently developed, received lawfully from another source without restriction, or public other than through breach. If disclosure is legally required, the receiving party will, where lawful, give prompt notice and disclose only what is required.")
    add_para(doc, "These obligations continue for five years after disclosure, and for trade secrets and Personal Information for as long as the information remains protected by law or confidential in nature.")

    add_heading(doc, "10. Privacy and security", 1)
    add_para(doc, "Each party will comply with Applicable Privacy Law for its own handling. Heutrix will handle Client Data only for the Services, on documented Client instructions, and in accordance with the Data Handling Schedule. If an instruction appears unlawful or materially unsafe, Heutrix will pause the affected handling and notify the Client.")
    add_para(doc, "The parties will minimise Personal Information and use synthetic, de-identified or redacted information where reasonably practicable. Personal Information must not be placed in website forms, ordinary project messages, public AI services or unapproved repositories.")
    add_para(doc, "Heutrix will maintain reasonable technical and organisational safeguards appropriate to the agreed data class, including access control, multi-factor authentication where available, least privilege, secure sharing, supported software, device protection and access removal. The detailed controls, approved systems and incident process are in Schedule 1.")

    add_heading(doc, "11. AI-supported work", 1)
    add_para(doc, "AI is not approved by default. Heutrix may use an AI system for Client work only where the SOW or an AI Use Case Approval identifies the tool, account, purpose, input data class, retention/training settings, hosting considerations, output use and accountable human reviewer.")
    add_para(doc, "AI must not make or replace clinical, care, safeguarding, eligibility, legal, employment, financial, compliance, regulatory or other significant decisions. Outputs must be reviewed by an appropriately skilled person before use. The detailed rules are in Schedule 2.")

    add_heading(doc, "12. Warranties and Australian Consumer Law", 1)
    add_para(doc, "Each party warrants that it has authority to enter this agreement. Heutrix warrants that the Services will materially conform to the SOW and be performed with due care and skill. The Client warrants that it has the rights and lawful authority needed for Heutrix to use Client Materials as instructed.")
    add_para(doc, "Nothing in this agreement excludes, restricts or modifies a guarantee, right or remedy that cannot lawfully be excluded, including under the Australian Consumer Law. Where the law permits liability for a non-personal, non-household service guarantee to be limited, Heutrix's liability is limited, at Heutrix's option, to supplying the Services again or paying the reasonable cost of having them supplied again, but only where it is fair and reasonable to rely on that limitation.")
    add_para(doc, "Except for express terms and non-excludable rights, neither party gives an implied warranty. The Client remains responsible for operational adoption, professional judgement, legal compliance and final decisions; this does not reduce Heutrix's responsibility for performing the agreed Services.")

    add_heading(doc, "13. Liability", 1)
    add_para(doc, "To the extent permitted by law, neither party is liable to the other for indirect or consequential loss, or loss of profit, revenue, opportunity or goodwill, except to the extent such loss forms part of a third-party claim covered by an indemnity or is a direct and reasonably foreseeable result of breach of confidentiality, privacy or security obligations.")
    add_para(doc, "For all claims arising from an affected SOW, each party's aggregate general liability is capped at the greater of two times the fees paid or payable under that SOW and AUD 10,000.")
    add_para(doc, "For claims arising from breach of confidentiality, privacy or security obligations, or the IP indemnity, each party's aggregate liability is capped at the greater of four times the fees paid or payable under the affected SOW and AUD 50,000.")
    add_para(doc, "The exclusions and caps do not apply to fees properly payable, fraud, wilful misconduct, or death or personal injury caused by negligence, and do not limit rights that cannot lawfully be limited. Liability is reduced to the extent the other party or a third party caused or contributed to the loss. The parties must take reasonable steps to mitigate loss.")

    add_heading(doc, "14. Third-party claims and indemnities", 1)
    add_para(doc, "Heutrix indemnifies the Client against a third-party claim that a Deliverable created solely by Heutrix infringes Australian IP rights, except to the extent caused by Client Materials, Client instructions, unauthorised modification, combination not approved by Heutrix or use outside the SOW. Heutrix may obtain rights, modify or replace the affected item, or refund the applicable unused fees if no reasonable remedy is available.")
    add_para(doc, "The Client indemnifies Heutrix against a third-party claim arising from Client Materials or instructions that the Client was not lawfully entitled to provide or require, except to the extent caused by Heutrix's breach, negligence or failure to follow lawful instructions.")
    add_para(doc, "An indemnified party must give prompt notice, reasonable assistance and control of the defence to the indemnifying party, subject to the indemnified party's right to participate. No settlement may admit fault or impose a non-monetary obligation on the indemnified party without its consent, not to be unreasonably withheld.")

    add_heading(doc, "15. Insurance", 1)
    add_para(doc, "Each party will maintain insurance required by law and any insurance expressly stated in the SOW. Before Services involving production access or Personal Information begin, the SOW must state the verified Heutrix insurance types and limits, or record the Client's informed acceptance that a specified cover is not held. Evidence of stated cover will be provided on reasonable request.")

    add_heading(doc, "16. Suspension", 1)
    add_para(doc, "Heutrix may suspend only the affected Services if an undisputed amount remains overdue five business days after written notice, or if continuing would create a material security, privacy, safety or legal risk. Heutrix must give reasons, limit the suspension, preserve Client Data and restore Services promptly when the issue is resolved. The Client is not charged for avoidable delay caused by an unjustified suspension.")

    add_heading(doc, "17. Termination", 1)
    add_para(doc, "Either party may terminate this agreement or an affected SOW for material breach not cured within 10 business days after written notice, immediately for an incurable material breach, or where the other party becomes insolvent to the extent permitted by law.")
    add_para(doc, "Either party may terminate a SOW for convenience on 10 business days' notice unless the SOW states a different notice period. The Client must pay for conforming Services performed and disclosed unavoidable commitments up to termination. Heutrix must refund prepaid amounts for Services not performed and provide reasonable handover of completed paid work.")
    add_para(doc, "Ending this agreement does not automatically end an existing SOW unless the notice says so. On termination, each party will return or delete Confidential Information and Client Data as required, remove access, and pay amounts properly due. Terms intended by nature to continue will survive, including confidentiality, privacy, IP, liability, disputes and payment rights.")

    add_heading(doc, "18. Disputes", 1)
    add_steps(doc, [
        "A party gives written notice describing the dispute and desired resolution.",
        "Project leads meet within five business days and try in good faith to resolve it.",
        "If unresolved after 10 business days, a director or senior delegate from each party meets.",
        "If unresolved after a further 10 business days, the parties attempt mediation in Melbourne through the Resolution Institute or another agreed mediator before court proceedings.",
    ], nums)
    add_para(doc, "This process does not prevent urgent injunctive relief, debt recovery for an undisputed amount, or action required to protect people, data, systems or limitation rights. The parties will continue undisputed obligations where reasonably possible.")

    add_heading(doc, "19. General", 1)
    add_para(doc, "The parties are independent contractors. Nothing creates employment, partnership, fiduciary or agency authority. Neither party may assign the agreement without the other's prior written consent, not to be unreasonably withheld, except to a related body corporate or successor to substantially all relevant business assets if the assignee can perform the obligations.")
    add_para(doc, "A party is not liable for delay caused by events beyond its reasonable control if it promptly notifies the other party and mitigates the effect. Payment obligations for Services already performed are not excused. Either party may terminate affected Services if the event continues for 30 days.")
    add_para(doc, "Changes and waivers must be in writing and authorised. Invalid terms are severed or read down only to the minimum extent required. This agreement is the entire agreement about its subject matter and does not exclude liability for fraud or misleading conduct.")
    add_para(doc, "This agreement is governed by the laws of Victoria, Australia. The parties submit to the courts of Victoria and courts hearing appeals from them.")

    add_heading(doc, "20. Notices and electronic signing", 1)
    add_para(doc, "A notice must be sent to the notice email in the signing block or the latest replacement notified in writing. A notice is received when the sender's system records successful transmission, unless sent after 5:00 pm or on a non-business day in the recipient's location, in which case it is received at 9:00 am on the next business day.")
    add_para(doc, "This agreement and a SOW may be signed electronically and in counterparts. The parties consent to reliable electronic methods that identify the signatory and indicate their intention to sign. Together, counterparts form one instrument.")

    doc.add_page_break()
    add_heading(doc, "Schedule 1 - Data Handling and Security", 1)
    add_callout(doc, "Activation", "This Schedule applies whenever Heutrix handles Client Data. A SOW must expressly approve any Personal Information, sensitive information, production access or offshore handling.")
    add_heading(doc, "A. Documented instructions and minimisation", 2)
    add_bullets(doc, [
        "Handle Client Data only for the authorised purpose, systems, users, locations and retention period stated in the SOW or access form.",
        "Collect or copy the minimum data needed. Prefer synthetic, de-identified or redacted information for discovery, design and testing.",
        "Do not sell Client Data, use it for advertising, use it to train a general model, combine it for unrelated profiling or disclose it except as authorised or legally required.",
        "Keep an access record for approved personnel and remove access when no longer needed or at project close.",
    ], nums)
    add_heading(doc, "B. Minimum safeguards", 2)
    add_bullets(doc, [
        "Use only the approved Client tenant or Heutrix workspace identified in the SOW. The approved platform categories are Google Workspace and Microsoft 365/SharePoint; exact applications and settings must still be approved.",
        "Use named accounts, least privilege and multi-factor authentication where available. Do not share credentials in ordinary email or project messages.",
        "Use supported devices with encryption, screen lock, malware protection and timely security updates. Avoid local downloads unless expressly approved.",
        "Use encrypted transport, access-controlled sharing and secure deletion appropriate to the data class.",
        "Do not use live Personal Information in development or testing unless the SOW explains why de-identified data is not reasonably practicable and states additional controls.",
        "Maintain reasonable backup and recovery arrangements for Heutrix-controlled project repositories, without overriding the Client's responsibility for Client systems.",
    ], nums)
    add_heading(doc, "C. Security incidents", 2)
    add_para(doc, "Heutrix will notify the Client without undue delay and, where practicable, within 24 hours after becoming aware of a Security Incident affecting Client Data. Initial notice may be incomplete and will be updated as facts become available.")
    add_bullets(doc, [
        "The notice will describe what happened, affected systems and data, likely consequences, containment steps, evidence preservation and a contact person, to the extent known.",
        "Heutrix will promptly contain, investigate, remediate and cooperate with the Client's assessment and legally required notifications.",
        "Neither party will notify individuals, regulators or media on behalf of the other without coordination, unless legally required. Each party remains responsible for its own statutory decisions and deadlines.",
        "Reasonable incident assistance caused by Heutrix's breach is at Heutrix's cost; assistance caused by the Client or unrelated events is handled under the SOW or a change request.",
    ], nums)
    add_heading(doc, "D. Subcontractors and overseas handling", 2)
    add_para(doc, "The SOW must list approved subprocessors and likely countries or regions for Personal Information where practicable. Heutrix will give reasonable prior notice of a material new subprocessor that will access Personal Information. The Client may object on reasonable privacy or security grounds; the parties will seek an alternative or may terminate the affected Services without penalty if no reasonable alternative exists.")
    add_para(doc, "Heutrix will not transfer or make Personal Information accessible outside Australia unless approved in the SOW and the parties have assessed applicable cross-border obligations, provider terms, access controls and risk.")
    add_heading(doc, "E. Requests, return and deletion", 2)
    add_para(doc, "Heutrix will promptly refer access, correction, complaint, regulator or legal requests concerning Client Data to the Client, unless prohibited by law, and provide reasonable assistance. Heutrix will not respond substantively on the Client's behalf without authority.")
    add_para(doc, "At the earlier of instruction, access expiry or project close, Heutrix will return agreed Client Data and securely delete remaining copies within 30 days, except where law requires retention. Residual backup copies will remain protected and be deleted through the normal cycle, targeted not to exceed 90 days. The handover form records completion and any exception.")

    doc.add_page_break()
    add_heading(doc, "Schedule 2 - Controlled AI Use", 1)
    add_callout(doc, "Default rule", "No AI tool or use case is approved unless it is recorded in the SOW or a signed AI Use Case Approval.")
    add_heading(doc, "A. Approved use-case record", 2)
    table = doc.add_table(rows=1, cols=2)
    fields = [
        ("Tool and account", "________________________________________________________"),
        ("Purpose and output", "________________________________________________________"),
        ("Permitted input data", "Public / internal / confidential / personal / sensitive (circle approved class)"),
        ("Training and retention settings", "________________________________________________________"),
        ("Hosting / access region", "________________________________________________________"),
        ("Human reviewer and competence", "________________________________________________________"),
        ("Prohibited uses", "________________________________________________________"),
        ("Approval / expiry", "________________________________________________________"),
    ]
    table.rows[0].cells[0].text = "Field"
    table.rows[0].cells[1].text = "Approved setting"
    for cell in table.rows[0].cells:
        set_cell_shading(cell, NAVY)
        style_cell_text(cell, bold=True, color=WHITE, size=9)
    set_repeat_header(table.rows[0])
    for label, value in fields:
        cells = table.add_row().cells
        cells[0].text = label
        cells[1].text = value
        style_cell_text(cells[0], bold=True, color=NAVY, size=9)
        style_cell_text(cells[1], size=9)
    set_table_geometry(table, [2700, 6660])
    set_table_borders(table)
    add_heading(doc, "B. Mandatory controls", 2)
    add_bullets(doc, [
        "Do not enter identifiable patient, participant, worker, staff or other sensitive information into a public or consumer AI service.",
        "Use only approved enterprise accounts and settings. Disable model training or provider reuse where required by the approved record.",
        "Minimise input data, remove identifiers and confidential details, and verify that prompts and outputs do not disclose protected information.",
        "Treat outputs as drafts. An accountable and appropriately skilled human must check accuracy, context, bias, confidentiality, professional suitability and legal requirements before use.",
        "Do not use AI to make or recommend clinical, treatment, safeguarding, eligibility, legal, employment, financial, compliance or regulatory decisions.",
        "Maintain the evidence appropriate to the use case, including approved instructions, material source references, review outcome and final accountable decision.",
        "Stop and escalate hallucinations, unexpected disclosure, unsafe output, model changes or incidents that could materially affect the approved risk assessment.",
    ], nums)
    add_signature_block(doc, "Signed for Heutrix Pty Ltd", "Signed for the Client")
    save(doc, "01_Heutrix_Client_Services_Agreement.docx")


def workflow_diagnostic_order() -> None:
    doc = Document()
    nums = configure_document(doc, "Workflow Diagnostic Order Form")
    add_kicker(doc, "Order form")
    add_title(doc, "Workflow Diagnostic", "One workflow. A clear current-state view. A practical next step.")
    add_metadata(doc, [
        ("Provider", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Client legal name", "________________________________________________________"),
        ("Client ABN / ACN", "________________________________________________________"),
        ("Workflow in scope", "________________________________________________________"),
        ("Fee", "AUD 950 plus GST, if GST is lawfully payable"),
        ("Order date", "________________________________________________________"),
        ("CSA", f"Heutrix Client Services Agreement v{VERSION}, dated {ISSUE_DATE}"),
    ], alert_rows={0})
    add_callout(doc, "Contract", "This signed Order Form and the identified Client Services Agreement form the contract. The Client confirms it received the complete CSA before signing.")

    add_heading(doc, "1. Outcome", 1)
    add_para(doc, "Heutrix will review one defined operational workflow, map how it operates now, identify material friction and visibility gaps, and recommend the simplest practical improvement options. The Diagnostic is intended to support an informed next-step decision; it is not an implementation project or assurance review.")

    add_heading(doc, "2. Included Services", 1)
    add_bullets(doc, [
        "A short kickoff and data-handling check with the Client project owner.",
        "One remote structured discovery workshop of up to 90 minutes with up to four Client participants.",
        "Review of up to five relevant documents or 50 pages in total, using redacted, de-identified or synthetic material unless separately approved.",
        "A current-state workflow map showing key steps, roles, information, decisions, handovers and material failure points.",
        "A practical future-state workflow map at an appropriate level of detail.",
        "A prioritised list of improvement opportunities and high-level implementation options, which may include process changes, tracking, visibility, automation, controlled AI or no technology change.",
        "One remote findings presentation of up to 60 minutes.",
        "A concise written findings report summarising scope, evidence, assumptions, observations, recommendations, dependencies and next steps.",
    ], nums)

    add_heading(doc, "3. Exclusions", 1)
    add_bullets(doc, [
        "System configuration, software development, automation build, dashboard build, data migration, integration, production deployment or ongoing support.",
        "Clinical, medical, legal, tax, employment, regulatory, official audit, NDIS registration, compliance assurance, mock audit or certification advice.",
        "Detailed security testing, penetration testing, privacy impact assessment, clinical safety assessment or formal accessibility audit.",
        "Travel, on-site workshops, translation, transcription, extensive document review or consultation outside the stated limits.",
        "Use of identifiable patient, participant, worker or staff information, unless added through a signed change and data authorisation.",
    ], nums)

    add_heading(doc, "4. Deliverables and acceptance", 1)
    table = doc.add_table(rows=1, cols=3)
    headers = ["Deliverable", "Acceptance criteria", "Target"]
    for cell, text in zip(table.rows[0].cells, headers):
        cell.text = text
        set_cell_shading(cell, NAVY)
        style_cell_text(cell, bold=True, color=WHITE, size=9)
    set_repeat_header(table.rows[0])
    rows = [
        ("Current-state map", "Covers agreed start/end, material roles, handovers, decisions and known pain points.", "Draft with report"),
        ("Future-state map", "Shows recommended ownership, controls and material changes at a practical level.", "Draft with report"),
        ("Opportunity list", "Prioritised with rationale, dependencies and a high-level option for each material item.", "Draft with report"),
        ("Findings report", "Addresses the agreed workflow and distinguishes evidence, assumptions and recommendations.", "Within 10 business days of inputs"),
        ("Presentation", "Walkthrough completed and material Client questions recorded.", "Within 5 business days of draft"),
    ]
    for vals in rows:
        cells = table.add_row().cells
        for cell, val in zip(cells, vals):
            cell.text = val
        style_cell_text(cells[0], bold=True, color=NAVY, size=8.8)
        style_cell_text(cells[1], size=8.8)
        style_cell_text(cells[2], size=8.8, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_table_geometry(table, [2100, 5160, 2100])
    set_table_borders(table)
    add_para(doc, "The Client has five business days to accept the draft or give specific reasons it does not meet these criteria. One consolidated reasonable correction round is included. New scope or preference changes require a Change Request.")

    add_heading(doc, "5. Client inputs and assumptions", 1)
    add_bullets(doc, [
        "The Client appoints one project owner who consolidates feedback and has authority to confirm operational facts.",
        "The workflow is sufficiently narrow to cover in one workshop and starts and ends at the points recorded below.",
        "The Client provides agreed documents and participant availability within five business days after payment.",
        "Work is remote and conducted during Melbourne business hours unless agreed otherwise.",
        "The Diagnostic relies on information supplied by the Client and is not an independent audit or verification of compliance.",
    ], nums)
    add_metadata(doc, [
        ("Workflow start", "________________________________________________________"),
        ("Workflow end", "________________________________________________________"),
        ("Client project owner", "________________________________________________________"),
        ("Workshop attendees", "________________________________________________________"),
        ("Documents to review", "________________________________________________________"),
    ])

    add_heading(doc, "6. Timing", 1)
    add_metadata(doc, [
        ("Payment due", "Before commencement, following a valid invoice"),
        ("Target workshop date", "________________________________________________________"),
        ("Inputs due", "________________________________________________________"),
        ("Target draft date", "10 business days after payment and receipt of agreed inputs"),
        ("Target presentation", "________________________________________________________"),
    ])
    add_para(doc, "Dates move reasonably if Client dependencies are late. Heutrix will notify the Client of the revised target and minimise avoidable delay.")

    add_heading(doc, "7. Fees and payment", 1)
    add_para(doc, "Fixed fee: AUD 950 plus GST if Heutrix is registered or required to be registered for GST. The fee is invoiced in advance and due within seven calendar days. Work begins after cleared payment and receipt of required inputs.")
    add_para(doc, "The fixed fee covers only the Included Services and one correction round. Extra work proceeds only under a signed Change Request. Approved travel or third-party costs are not included and cannot be incurred without written Client approval.")

    add_heading(doc, "8. Data, system and AI settings", 1)
    add_callout(doc, "Default data class", "No Personal Information or sensitive information. Use synthetic, de-identified or appropriately redacted material only.")
    settings = [
        ("Approved repository", "Client-controlled Google Workspace / SharePoint / other: ____________________"),
        ("Production system access", "Not approved"),
        ("Personal or health information", "Not approved"),
        ("Local download", "Not approved unless required for an approved redacted document"),
        ("AI use", "No Client Confidential Information or Client Data in AI. Public/general research only unless a signed AI approval is attached."),
        ("Retention", "Return/delete project Client Data within 30 days after acceptance, subject to lawful retention and backup cycle"),
    ]
    add_metadata(doc, settings)

    add_heading(doc, "9. Intellectual property", 1)
    add_para(doc, "The Client-owned Deliverable model in the CSA applies: on full payment, the Client owns the project-specific maps and report, excluding Heutrix Background Materials and third-party materials. The Client receives the embedded licence described in the CSA.")

    add_heading(doc, "10. Special Conditions", 1)
    add_para(doc, "________________________________________________________________________________")
    add_para(doc, "________________________________________________________________________________")
    add_para(doc, "If blank, no Special Conditions apply.")
    add_signature_block(doc, "Signed for Heutrix Pty Ltd", "Signed for the Client")
    save(doc, "02_Heutrix_Workflow_Diagnostic_Order_Form.docx")


def general_sow() -> None:
    doc = Document()
    nums = configure_document(doc, "Statement of Work Template")
    add_kicker(doc, "Project template")
    add_title(doc, "Statement of Work", "For workflow builds, visibility builds, Safe AI packs and tailored internal systems")
    add_metadata(doc, [
        ("SOW number", "____________________________"),
        ("Provider", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Client legal name", "________________________________________________________"),
        ("Project", "________________________________________________________"),
        ("SOW date", "________________________________________________________"),
        ("CSA", f"Heutrix Client Services Agreement v{VERSION}, dated {ISSUE_DATE}"),
    ], alert_rows={1})
    add_callout(doc, "Completion rule", "Do not sign this SOW until every selection affecting scope, fees, data, AI, IP, insurance and acceptance has been completed. Delete unused options in the client issue copy.")

    add_heading(doc, "1. Project outcome and scope boundary", 1)
    add_metadata(doc, [
        ("Operational problem", "________________________________________________________"),
        ("Workflow start / end", "________________________________________________________"),
        ("Target outcome", "________________________________________________________"),
        ("In-scope teams / users", "________________________________________________________"),
        ("Out-of-scope work", "________________________________________________________"),
    ])
    add_para(doc, "Project description:")
    for _ in range(5):
        add_para(doc, "________________________________________________________________________________")

    add_heading(doc, "2. Services and deliverables", 1)
    table = doc.add_table(rows=1, cols=5)
    for cell, text in zip(table.rows[0].cells, ["#", "Service / deliverable", "Owner", "Target", "Acceptance criteria"]):
        cell.text = text
        set_cell_shading(cell, NAVY)
        style_cell_text(cell, bold=True, color=WHITE, size=8.5)
    set_repeat_header(table.rows[0])
    for i in range(1, 7):
        cells = table.add_row().cells
        cells[0].text = str(i)
        cells[1].text = ""
        cells[2].text = ""
        cells[3].text = ""
        cells[4].text = ""
        for idx, cell in enumerate(cells):
            style_cell_text(cell, size=8.5, align=WD_ALIGN_PARAGRAPH.CENTER if idx in (0, 2, 3) else WD_ALIGN_PARAGRAPH.LEFT)
            cell.paragraphs[0].add_run("\n\n")
    set_table_geometry(table, [500, 2700, 1200, 1400, 3560])
    set_table_borders(table)

    add_heading(doc, "3. Approach, milestones and governance", 1)
    add_metadata(doc, [
        ("Target start", "________________________________________________________"),
        ("Target completion", "________________________________________________________"),
        ("Heutrix lead", "________________________________________________________"),
        ("Client project owner", "________________________________________________________"),
        ("Meeting / reporting cadence", "________________________________________________________"),
        ("Review period", "Five business days unless stated here: ____________________"),
    ])
    add_bullets(doc, [
        "The Client project owner consolidates feedback and decisions.",
        "The parties record material decisions, assumptions, risks and approvals in the agreed repository.",
        "A signed Change Request is required before material changes to scope, fees, dates, data, tools, access or acceptance criteria.",
    ], nums)

    add_heading(doc, "4. Client dependencies and assumptions", 1)
    for _ in range(6):
        add_para(doc, "________________________________________________________________________________")

    add_heading(doc, "5. Fees and invoicing", 1)
    table = doc.add_table(rows=1, cols=4)
    for cell, text in zip(table.rows[0].cells, ["Milestone / basis", "Amount ex GST", "Invoice trigger", "Payment due"]):
        cell.text = text
        set_cell_shading(cell, NAVY)
        style_cell_text(cell, bold=True, color=WHITE, size=8.8)
    set_repeat_header(table.rows[0])
    for _ in range(5):
        cells = table.add_row().cells
        for cell in cells:
            cell.text = "\n"
            style_cell_text(cell, size=8.8)
    set_table_geometry(table, [3100, 1800, 2860, 1600])
    set_table_borders(table)
    add_metadata(doc, [
        ("Total fees ex GST", "AUD ______________________________"),
        ("GST", "Payable only if Heutrix is registered or required to be registered and issues a valid tax invoice"),
        ("Approved expenses", "None / as follows: ________________________________________"),
        ("Rate for approved extra work", "AUD __________ per hour/day, ex GST"),
    ])

    add_heading(doc, "6. Intellectual property model - select one", 1)
    add_bullets(doc, [
        "[  ] Client-owned Deliverables. The CSA default applies on full payment, excluding Heutrix Background Materials and third-party materials.",
        "[  ] Heutrix-licensed solution. Licence scope, users, term, support, portability and exit rights: ________________________________________________.",
        "[  ] Other signed IP arrangement: ________________________________________________________________.",
    ], nums)

    add_heading(doc, "7. Data classification and access", 1)
    add_metadata(doc, [
        ("Highest data class", "[  ] Public  [  ] Internal  [  ] Confidential  [  ] Personal  [  ] Sensitive / health"),
        ("Approved data categories", "________________________________________________________"),
        ("Prohibited data", "________________________________________________________"),
        ("Approved repository / tenant", "________________________________________________________"),
        ("Approved systems and access", "________________________________________________________"),
        ("Storage / access countries", "________________________________________________________"),
        ("Approved subprocessors", "________________________________________________________"),
        ("Access end date", "________________________________________________________"),
        ("Return / deletion", "________________________________________________________"),
    ])
    add_callout(doc, "Attachment required", "If Personal Information, sensitive information or production access is selected, attach a completed Data and System Access Authorisation before access begins.", fill=PALE_YELLOW)

    add_heading(doc, "8. AI setting - select one", 1)
    add_bullets(doc, [
        "[  ] No AI use for this SOW.",
        "[  ] AI limited to public/general research with no Client Data or Confidential Information.",
        "[  ] Approved AI use is recorded in the attached AI Use Case Approval dated ____________________.",
    ], nums)

    add_heading(doc, "9. Security, continuity and handover", 1)
    add_metadata(doc, [
        ("Authentication / MFA", "________________________________________________________"),
        ("Backup owner", "________________________________________________________"),
        ("Business continuity requirement", "________________________________________________________"),
        ("Testing / rollback", "________________________________________________________"),
        ("Documentation and training", "________________________________________________________"),
        ("Support / warranty period", "________________________________________________________"),
        ("Handover items", "________________________________________________________"),
    ])

    add_heading(doc, "10. Insurance - insert verified cover only", 1)
    add_metadata(doc, [
        ("Professional indemnity", "Insurer / policy / limit / expiry: __________________________________"),
        ("Public liability", "Insurer / policy / limit / expiry: __________________________________"),
        ("Cyber", "Insurer / policy / limit / expiry: __________________________________"),
        ("Client requirement / accepted gap", "________________________________________________________"),
    ], alert_rows={0, 1, 2, 3})

    add_heading(doc, "11. Special Conditions", 1)
    for _ in range(5):
        add_para(doc, "________________________________________________________________________________")
    add_signature_block(doc, "Signed for Heutrix Pty Ltd", "Signed for the Client")
    save(doc, "03_Heutrix_General_Statement_of_Work_Template.docx")


def mutual_nda() -> None:
    doc = Document()
    nums = configure_document(doc, "Mutual Confidentiality Agreement")
    add_kicker(doc, "Pre-engagement")
    add_title(doc, "Mutual Confidentiality Agreement", "For evaluating and discussing a potential Heutrix engagement")
    add_metadata(doc, [
        ("Heutrix", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Other party", "________________________________________________________"),
        ("Purpose", "Evaluate and discuss: ________________________________________"),
        ("Effective date", "________________________________________________________"),
        ("Version", f"{VERSION} | {ISSUE_DATE}"),
    ], alert_rows={0})
    add_callout(doc, "No engagement", "This agreement protects information exchanged for the Purpose. It does not appoint Heutrix, require either party to proceed, approve system/data access or authorise AI use.")

    add_heading(doc, "1. Confidential Information", 1)
    add_para(doc, "Confidential Information means non-public information disclosed by or for a party in any form that is marked confidential or that a reasonable person would understand is confidential given its nature and the circumstances. It includes business plans, pricing, processes, systems, security information, product ideas, IP, client or worker information, Personal Information and the existence and content of discussions.")
    add_para(doc, "Confidential Information excludes information the receiving party can demonstrate was lawfully known without restriction before disclosure, independently developed without use of the information, lawfully received from a third party without restriction, or public other than through breach.")

    add_heading(doc, "2. Permitted use and protection", 1)
    add_bullets(doc, [
        "Use Confidential Information only for the Purpose.",
        "Disclose it only to personnel and professional advisers who need it for the Purpose and are bound by confidentiality obligations.",
        "Protect it with at least reasonable care and safeguards appropriate to its sensitivity.",
        "Do not copy, reverse engineer or analyse it beyond what is reasonably required for the Purpose.",
        "Promptly notify the disclosing party of known unauthorised access, use or disclosure and cooperate in reasonable containment.",
        "Do not place Confidential Information or Personal Information into a public AI tool or unapproved repository.",
    ], nums)

    add_heading(doc, "3. Personal and health information", 1)
    add_para(doc, "The parties will avoid exchanging identifiable patient, participant, worker or other sensitive information during preliminary discussions. If Personal Information is genuinely required, the parties will first document the lawful purpose, authority, minimum data, approved channel, access, retention and deletion arrangements.")
    add_para(doc, "Each party remains responsible for Applicable Privacy Law. This agreement does not replace a project-specific Data and System Access Authorisation.")

    add_heading(doc, "4. Legally required disclosure", 1)
    add_para(doc, "If disclosure is required by law, court or regulator, the receiving party may disclose the minimum required. Where lawful and practicable, it will give prompt notice so the disclosing party can seek protection and will reasonably assist at the disclosing party's cost.")

    add_heading(doc, "5. Return and deletion", 1)
    add_para(doc, "On request or when discussions end, the receiving party will stop using and return or securely delete Confidential Information within 10 business days, except for a copy required by law or automatic backups not reasonably accessible. Retained copies remain protected and are not used for another purpose.")

    add_heading(doc, "6. Ownership, accuracy and no commitment", 1)
    add_para(doc, "Confidential Information remains the disclosing party's property. No IP licence is granted except the limited right to use it for the Purpose. Information is supplied without a promise that it is complete or accurate, except that neither party excludes responsibility for fraud or misleading conduct.")
    add_para(doc, "Neither party is obliged to proceed with a transaction or engagement. Any paid work, system access, deliverable, reliance or commercial commitment requires a separate signed agreement.")

    add_heading(doc, "7. Term and survival", 1)
    add_para(doc, "This agreement applies to disclosures made for three years after the Effective date. The confidentiality and use restrictions continue for five years after each disclosure. For trade secrets and Personal Information, they continue for as long as the information remains confidential or protected by law.")

    add_heading(doc, "8. Remedies and liability", 1)
    add_para(doc, "The parties acknowledge that unauthorised use or disclosure may cause harm not adequately remedied by damages, so a party may seek urgent injunctive relief. Each party remains responsible for loss it causes through breach, subject to applicable law and the general duty to mitigate.")

    add_heading(doc, "9. General", 1)
    add_para(doc, "This agreement is the entire agreement about confidentiality for the Purpose and may be changed only in writing signed by both parties. Invalid terms are read down or severed to the minimum extent required. Neither party may assign it without the other's consent, except to a successor to substantially all relevant business assets that assumes the obligations.")
    add_para(doc, "The agreement is governed by Victoria, Australia. The parties submit to Victorian courts. It may be signed electronically and in counterparts.")
    add_signature_block(doc, "Signed for Heutrix Pty Ltd", "Signed for the other party")
    save(doc, "04_Heutrix_Mutual_Confidentiality_Agreement.docx")


def form_title(doc, title: str, subtitle: str, code: str) -> None:
    if len(doc.paragraphs) > 1:
        doc.add_page_break()
    add_kicker(doc, f"Project control form | {code}")
    add_title(doc, title, subtitle)
    add_metadata(doc, [
        ("Project / SOW", "________________________________________________________"),
        ("Client", "________________________________________________________"),
        ("Form date", "________________________________________________________"),
        ("Prepared by", "________________________________________________________"),
    ])


def project_forms_pack() -> None:
    doc = Document()
    nums = configure_document(doc, "Project Control Forms")
    add_kicker(doc, "Client and project controls")
    add_title(doc, "Project Control Forms", "Access, AI approval, change control, acceptance and secure handover")
    add_metadata(doc, [
        ("Provider", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Version", f"{VERSION} | {ISSUE_DATE}"),
        ("Use with", "Heutrix Client Services Agreement and signed SOW"),
    ], alert_rows={0})
    add_callout(doc, "Use", "Complete the relevant form before the event it controls. A form does not expand the Services unless it is also signed as a Change Request where fees, timing or scope change.")
    add_heading(doc, "Forms in this pack", 1)
    add_bullets(doc, [
        "A. Data and System Access Authorisation",
        "B. AI Use Case Approval",
        "C. Change Request",
        "D. Deliverable Review and Acceptance",
        "E. Handover and Access Closure",
    ], nums)

    form_title(doc, "Data and System Access Authorisation", "Records the minimum approved access before Heutrix enters a Client system or handles protected data.", "A")
    add_heading(doc, "Authorised purpose and scope", 1)
    add_metadata(doc, [
        ("Business purpose", "________________________________________________________"),
        ("System / tenant / site", "________________________________________________________"),
        ("Environment", "[  ] Sandbox  [  ] Test  [  ] Production  [  ] Other: __________"),
        ("Access start", "____________________"),
        ("Access expiry", "____________________"),
        ("Heutrix authorised user(s)", "________________________________________________________"),
        ("Access level", "[  ] View  [  ] Edit  [  ] Admin  [  ] API / service account"),
    ])
    add_heading(doc, "Approved data", 1)
    add_metadata(doc, [
        ("Classification", "[  ] Public  [  ] Internal  [  ] Confidential  [  ] Personal  [  ] Sensitive / health"),
        ("Data categories", "________________________________________________________"),
        ("Data subjects", "________________________________________________________"),
        ("Prohibited fields", "________________________________________________________"),
        ("De-identification / test data", "________________________________________________________"),
        ("Approximate volume", "________________________________________________________"),
    ])
    add_heading(doc, "Controls and authority", 1)
    add_metadata(doc, [
        ("Authentication / MFA", "________________________________________________________"),
        ("Approved device / location", "________________________________________________________"),
        ("Download / export", "[  ] Prohibited  [  ] Approved only as follows: __________________"),
        ("Approved storage", "________________________________________________________"),
        ("Subprocessors / countries", "________________________________________________________"),
        ("Monitoring / logs", "________________________________________________________"),
        ("Return / deletion", "________________________________________________________"),
        ("Client legal authority", "Consent / contract / law / other: __________________________"),
        ("Client privacy notice", "[  ] Confirmed  [  ] Not applicable  [  ] Action required"),
    ])
    add_para(doc, "The Client confirms it has authority to grant this access and provide the approved data. Heutrix accepts the access only for the stated purpose and controls. Any expansion requires written approval and, where material, a signed Change Request.")
    add_signature_block(doc, "Approved by Heutrix", "Approved by the Client")

    form_title(doc, "AI Use Case Approval", "Approves one tool and one defined use case with accountable human review.", "B")
    add_heading(doc, "Use case", 1)
    add_metadata(doc, [
        ("Tool / model / version", "________________________________________________________"),
        ("Account / tenant", "________________________________________________________"),
        ("Purpose", "________________________________________________________"),
        ("Input", "________________________________________________________"),
        ("Output and audience", "________________________________________________________"),
        ("Frequency / volume", "________________________________________________________"),
    ])
    add_heading(doc, "Data and provider settings", 1)
    add_metadata(doc, [
        ("Maximum input class", "[  ] Public  [  ] Internal  [  ] Confidential  [  ] Personal  [  ] Sensitive"),
        ("Identifiers removed", "[  ] Yes  [  ] No - explain: _________________________________"),
        ("Provider training / reuse", "[  ] Disabled  [  ] Not applicable  [  ] Other: __________"),
        ("Retention", "________________________________________________________"),
        ("Hosting / access countries", "________________________________________________________"),
        ("Contract / privacy review", "________________________________________________________"),
    ])
    add_heading(doc, "Human control and prohibited use", 1)
    add_metadata(doc, [
        ("Accountable owner", "________________________________________________________"),
        ("Human reviewer", "________________________________________________________"),
        ("Review checklist", "Accuracy / source / context / bias / privacy / professional suitability / other"),
        ("Final decision owner", "________________________________________________________"),
        ("Prohibited reliance", "Clinical / care / safeguarding / eligibility / legal / employment / financial / compliance / regulatory"),
        ("Escalation trigger", "________________________________________________________"),
        ("Approval expiry / review date", "________________________________________________________"),
    ])
    add_callout(doc, "Approval condition", "AI output is a draft. Approval does not transfer professional, clinical, privacy, compliance or management responsibility to the tool.", fill=PALE_YELLOW)
    add_signature_block(doc, "Approved by Heutrix", "Approved by the Client")

    form_title(doc, "Change Request", "Records the agreed effect of a project change before work proceeds.", "C")
    add_metadata(doc, [
        ("Change number", "____________________________"),
        ("Requested by", "________________________________________________________"),
        ("Reason", "________________________________________________________"),
        ("Description", "________________________________________________________"),
    ])
    add_heading(doc, "Impact assessment", 1)
    add_metadata(doc, [
        ("Scope / deliverables", "________________________________________________________"),
        ("Acceptance criteria", "________________________________________________________"),
        ("Schedule", "Old: ____________________  New: ____________________"),
        ("Fees ex GST", "Increase / decrease: AUD ______________________________"),
        ("Expenses / licences", "________________________________________________________"),
        ("Data / access", "________________________________________________________"),
        ("Privacy / security", "________________________________________________________"),
        ("AI", "________________________________________________________"),
        ("IP / third-party terms", "________________________________________________________"),
        ("Risks / dependencies", "________________________________________________________"),
    ])
    add_para(doc, "When signed, this Change Request amends the identified SOW only. All other terms continue. No changed work begins before the effective date below, except documented emergency protection steps.")
    add_signature_block(doc, "Agreed by Heutrix", "Agreed by the Client")

    form_title(doc, "Deliverable Review and Acceptance", "Records objective review against the SOW without waiving non-excludable rights or latent defects.", "D")
    add_metadata(doc, [
        ("Deliverable / version", "________________________________________________________"),
        ("Submitted", "________________________________________________________"),
        ("Review period ends", "________________________________________________________"),
        ("Acceptance Criteria reference", "________________________________________________________"),
    ])
    add_heading(doc, "Review result", 1)
    add_bullets(doc, [
        "[  ] Accepted - the Deliverable meets the Acceptance Criteria.",
        "[  ] Accepted with minor items - the Deliverable may be used, subject to the actions below.",
        "[  ] Not accepted - the specific material non-conformities and evidence are listed below.",
    ], nums)
    add_metadata(doc, [
        ("Evidence / test result", "________________________________________________________"),
        ("Required correction", "________________________________________________________"),
        ("Owner", "________________________________________________________"),
        ("Target resubmission", "________________________________________________________"),
        ("Residual risks / open items", "________________________________________________________"),
    ])
    add_para(doc, "Acceptance is for project administration and does not waive a latent defect, an express warranty, a consumer guarantee or a right that cannot lawfully be excluded.")
    add_signature_block(doc, "Acknowledged by Heutrix", "Decision by the Client")

    form_title(doc, "Handover and Access Closure", "Confirms delivery, knowledge transfer, access removal and data disposition at project close.", "E")
    add_heading(doc, "Handover checklist", 1)
    add_bullets(doc, [
        "[  ] Final Deliverables and source/editable files provided as agreed.",
        "[  ] User guide, operating notes, configuration and maintenance instructions provided.",
        "[  ] Training or walkthrough completed; attendance/evidence recorded.",
        "[  ] Client ownership, licence and third-party dependencies recorded.",
        "[  ] Known limitations, residual risks and open actions recorded.",
        "[  ] Client confirms backup and business-continuity ownership.",
        "[  ] Heutrix named-user, admin, API and temporary access removed.",
        "[  ] Credentials or secrets rotated where required; none copied into this form.",
        "[  ] Client Data returned or securely deleted as agreed.",
        "[  ] Backup retention exception and final deletion date recorded.",
    ], nums)
    add_metadata(doc, [
        ("Handover location", "________________________________________________________"),
        ("Access removed on", "________________________________________________________"),
        ("Data returned / deleted on", "________________________________________________________"),
        ("Backup exception / deletion target", "________________________________________________________"),
        ("Support start / end", "________________________________________________________"),
        ("Open items and owners", "________________________________________________________"),
    ])
    add_signature_block(doc, "Closed by Heutrix", "Confirmed by the Client")
    save(doc, "05_Heutrix_Project_Control_Forms.docx")


def privacy_policy() -> None:
    doc = Document()
    nums = configure_document(doc, "Privacy Policy and Collection Notices")
    add_kicker(doc, "Public legal notice")
    add_title(doc, "Privacy Policy", "How Heutrix handles personal and health information")
    add_metadata(doc, [
        ("Entity", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Effective", ISSUE_DATE),
        ("Privacy contact", "Use the Heutrix website contact form and mark the message 'Privacy'"),
        ("Version", VERSION),
    ], alert_rows={0})
    add_callout(doc, "Publication check", "Before publishing, reconcile this policy to the live website forms, cookies, analytics, CRM, booking service, email platform, cloud tenants, subprocessors and actual overseas access locations.", fill=PALE_YELLOW)

    add_heading(doc, "1. Scope and our approach", 1)
    add_para(doc, "Heutrix provides workflow improvement, practical systems, operational visibility and controlled AI support to Australian allied health practices and disability support providers. This policy explains how Heutrix Pty Ltd collects, holds, uses and discloses personal information.")
    add_para(doc, "Heutrix complies with privacy and health-records laws that apply to its handling, including the Privacy Act 1988 (Cth) where applicable and the Health Records Act 2001 (Vic) for health information handled in Victoria. Where a law does not technically apply, Heutrix aims to use practices consistent with the Australian Privacy Principles as a baseline, subject to legal and operational context.")

    add_heading(doc, "2. Information we collect", 1)
    add_bullets(doc, [
        "Contact and identity information, such as name, role, organisation, business email, phone number and correspondence details.",
        "Enquiry and relationship information, such as the workflow issue, service interest, meeting notes, proposals, contracts, feedback and communication preferences.",
        "Commercial and transaction information, such as billing contact, ABN/ACN, invoices and payment status. Heutrix does not need card details where payments are handled by a payment provider or bank.",
        "Project information, such as process documents, system details, access records, user feedback, requirements, decisions, testing evidence and Deliverables.",
        "Website and technical information made available by the website or its configured providers, such as IP address, device/browser details, referral page, form events, cookie choices and security logs.",
        "Applicant, worker or supplier information where a person applies to work with Heutrix or provides services to it.",
    ], nums)
    add_para(doc, "Heutrix does not ask for patient, participant, diagnosis, Medicare, clinical, worker-record or other sensitive information in website forms or an initial fit call. A general and non-identifying description is sufficient.")

    add_heading(doc, "3. Project personal and health information", 1)
    add_para(doc, "Some client workflows involve personal, sensitive or health information. Heutrix seeks to avoid receiving that information where synthetic, de-identified or redacted material can achieve the purpose. Before access, the parties document the purpose, authority, minimum data, systems, users, security, location, retention and deletion arrangements.")
    add_para(doc, "When Heutrix handles information on a client's instructions, the client remains responsible for its own notices, consents, professional duties and authority to disclose. Heutrix remains responsible for its own handling and contractual controls.")

    add_heading(doc, "4. How we collect information", 1)
    add_bullets(doc, [
        "Directly from a person through a website form, booking, email, call, workshop, contract, survey or project interaction.",
        "From a person's organisation, authorised representatives, referrals or project participants.",
        "From approved client systems and documents where a signed engagement authorises access.",
        "From public professional or business sources where reasonably necessary for a business relationship.",
        "Automatically through the website and security/hosting systems as configured at the time.",
    ], nums)

    add_heading(doc, "5. Why we collect and use information", 1)
    add_bullets(doc, [
        "Respond to enquiries, assess fit, schedule meetings and prepare proposals.",
        "Enter, manage and perform client engagements, including discovery, design, testing, delivery, support and handover.",
        "Manage accounts, invoices, suppliers, records, quality, risk, security and legal obligations.",
        "Improve services, methods and website operation using information that is de-identified or otherwise lawfully used.",
        "Send relevant service communications and, with required consent, marketing communications.",
        "Protect people, systems, information and legal rights, and respond to incidents, complaints and lawful requests.",
    ], nums)
    add_para(doc, "Heutrix will not use Client Data to train a general AI model, sell personal information, or use it for unrelated advertising.")

    add_heading(doc, "6. Disclosure and service providers", 1)
    add_para(doc, "Heutrix may disclose personal information only as reasonably required to: authorised Heutrix personnel and approved contractors; professional advisers and insurers; hosting, collaboration, booking, communications, invoicing, security and support providers; the relevant client or its authorised representatives; and regulators, courts or law-enforcement bodies where authorised or required.")
    add_para(doc, "Project access is limited to people who need it. Providers handling project data must be approved for the data class and bound by appropriate terms. Heutrix does not authorise a provider to use Client Data for its own unrelated purposes.")

    add_heading(doc, "7. Overseas access and cloud services", 1)
    add_para(doc, "Some configured technology providers may store information or permit support access outside Australia. Before Personal Information is used in a client project, the SOW or access authorisation should identify likely countries or regions where practicable and address applicable cross-border requirements.")
    add_para(doc, "Heutrix's approved platform categories for client project information are Google Workspace and Microsoft 365/SharePoint, but exact products, tenants, regions, settings and subprocessors must be approved. This policy must be updated when the production configuration is confirmed.")

    add_heading(doc, "8. Security", 1)
    add_para(doc, "Heutrix uses safeguards appropriate to the information and engagement, which may include access control, multi-factor authentication, least privilege, encryption in transit, supported devices, security updates, malware protection, controlled sharing, logging, backups and access removal. No method is completely secure, and Heutrix responds to suspected incidents through its incident process.")
    add_para(doc, "If a breach is likely to cause serious harm and notification law applies, Heutrix will assess and notify affected people and the relevant regulator as required. Where Heutrix handles data for a client, it will coordinate with the client under the contract.")

    add_heading(doc, "9. Retention and deletion", 1)
    add_para(doc, "Heutrix keeps personal information only for as long as reasonably needed for the purpose, contract, dispute, insurance and legal recordkeeping. Project-specific return and deletion periods are set in the SOW. When information is no longer required, Heutrix takes reasonable steps to securely delete or de-identify it, subject to lawful retention and backup cycles.")

    add_heading(doc, "10. AI and automated decisions", 1)
    add_para(doc, "Heutrix does not approve identifiable personal or health information for use in public generative AI tools. A client project may use an approved enterprise AI tool only after the use case, data, provider settings, location, retention, training controls and accountable human review are documented.")
    add_para(doc, "Heutrix does not use personal information to make solely automated decisions that have a legal or similarly significant effect on an individual. AI supports human work and does not replace clinical, care, safeguarding, legal, employment, financial, compliance or management decisions.")

    add_heading(doc, "11. Direct marketing", 1)
    add_para(doc, "Heutrix sends commercial email or messages only where it has consent or another lawful basis, identifies itself and provides a functional unsubscribe. A person may opt out at any time using the unsubscribe method or by contacting Heutrix. Service, security, contract and transaction messages may still be sent where necessary.")

    add_heading(doc, "12. Access and correction", 1)
    add_para(doc, "A person may ask to access or correct personal information Heutrix holds by using the website contact form and marking the message 'Privacy - access' or 'Privacy - correction'. Heutrix may verify identity, will respond within a reasonable period and will explain any lawful refusal. A permitted reasonable access charge will be disclosed before work begins; no fee is charged to request access or correction.")

    add_heading(doc, "13. Privacy questions and complaints", 1)
    add_para(doc, "Send a privacy question or complaint through the Heutrix website contact form and mark it 'Privacy complaint'. Include contact details, the relevant interaction and the outcome sought, but do not include unnecessary sensitive information. Heutrix will normally acknowledge within five business days, investigate fairly and aim to respond within 30 days.")
    add_para(doc, "If unresolved and the relevant law applies, a person may contact the Office of the Australian Information Commissioner at https://www.oaic.gov.au/ or the Victorian Health Complaints Commissioner at https://hcc.vic.gov.au/ for Victorian health information.")

    add_heading(doc, "14. Changes", 1)
    add_para(doc, "Heutrix may update this policy to reflect legal, service or technology changes. The current version will show its effective date. Material changes affecting an existing project will also be handled under the relevant contract where required.")

    doc.add_page_break()
    add_kicker(doc, "Website form notice")
    add_title(doc, "Privacy Collection Notice", "For enquiry, fit-call and download forms")
    add_para(doc, "Heutrix Pty Ltd collects the name, role, organisation, business contact details and general enquiry information entered in this form so it can respond, assess service fit, arrange a meeting, provide the requested resource and manage the resulting business relationship.")
    add_para(doc, "Do not include patient or participant names, Medicare details, diagnoses, clinical information, worker records, photos, credentials or other sensitive information. A general, non-identifying workflow description is enough.")
    add_para(doc, "If required information is not provided, Heutrix may be unable to respond or provide the requested item. Heutrix may disclose information to configured website, hosting, booking, communication and business-service providers and to authorised personnel. Some providers may process information overseas; the current Privacy Policy explains the approach and will identify locations where practicable after systems are finalised.")
    add_para(doc, "The Heutrix Privacy Policy explains access, correction and complaints. Use the website contact form and mark privacy requests 'Privacy'.")
    add_heading(doc, "Optional marketing consent - keep separate from the enquiry", 2)
    add_para(doc, "[  ] I agree to receive occasional Heutrix service updates and practical workflow/AI information by email. I can unsubscribe at any time.")
    add_para(doc, "Do not pre-select this box. Record when and how consent was given. A person can submit an enquiry without agreeing to marketing.")

    doc.add_page_break()
    add_kicker(doc, "Project notice template")
    add_title(doc, "Project Collection Notice", "Complete when Heutrix collects personal information directly during a client project")
    add_metadata(doc, [
        ("Client / project", "________________________________________________________"),
        ("Heutrix contact", "________________________________________________________"),
        ("Information collected", "________________________________________________________"),
        ("Purpose", "________________________________________________________"),
        ("Required / optional", "________________________________________________________"),
        ("Consequences if not provided", "________________________________________________________"),
        ("Usual disclosures", "________________________________________________________"),
        ("Overseas countries / regions", "________________________________________________________"),
        ("Access / correction / complaints", "________________________________________________________"),
    ])
    add_para(doc, "This notice supplements the Heutrix Privacy Policy and the client's own privacy notice. It must be completed and approved before use, and must reflect the actual information flow.")
    save(doc, "06_Heutrix_Privacy_Policy_and_Collection_Notices.docx")


def website_terms() -> None:
    doc = Document()
    nums = configure_document(doc, "Website Terms of Use")
    add_kicker(doc, "Public legal terms")
    add_title(doc, "Website Terms of Use", "Heutrix service information, enquiries and website access")
    add_metadata(doc, [
        ("Operator", "Heutrix Pty Ltd | ACN / ABN: ______________________________"),
        ("Effective", ISSUE_DATE),
        ("Contact", "Use the contact method on the Heutrix website"),
        ("Version", VERSION),
    ], alert_rows={0})
    add_callout(doc, "Publication check", "Complete the entity details and reconcile these terms to the live website functionality, downloads, forms, booking service, cookies and linked providers before publication.", fill=PALE_YELLOW)

    add_heading(doc, "1. Acceptance and scope", 1)
    add_para(doc, "These terms apply to access and use of the Heutrix website, forms and downloadable general resources. By using the website, a person agrees to these terms. If they do not agree, they should not use the website.")
    add_para(doc, "These website terms do not govern paid client Services. A fit call, enquiry, proposal or website form does not create an engagement. Paid work requires a written scope and commercial agreement signed by Heutrix and the Client.")

    add_heading(doc, "2. General information and service boundaries", 1)
    add_para(doc, "Website content explains Heutrix's workflow-improvement, operational-visibility, practical-system and controlled AI services. It is general information and is not legal, tax, financial, employment, clinical, medical, regulatory, official audit, NDIS registration, compliance assurance or professional advice for a particular person or organisation.")
    add_para(doc, "Heutrix does not guarantee cost savings, revenue, productivity, registration, compliance, regulator approval or business outcomes. A recommendation for a client depends on a signed scope, available evidence, data handling and feasibility review.")

    add_heading(doc, "3. Enquiries and sensitive information", 1)
    add_para(doc, "Do not submit patient names, participant records, Medicare details, diagnoses, clinical information, worker records, photos, credentials or other sensitive information through a website form, booking note or initial message. Use a general and non-identifying description. Heutrix may delete unsolicited sensitive information where lawful and appropriate.")

    add_heading(doc, "4. Acceptable use", 1)
    add_bullets(doc, [
        "Use the website lawfully and do not interfere with its operation, security or availability.",
        "Do not attempt unauthorised access, introduce malicious code, scrape at a harmful rate, impersonate another person or submit false or unlawful content.",
        "Do not use website content to misrepresent Heutrix, provide regulated advice or imply endorsement, partnership or assurance that Heutrix has not given in writing.",
        "Do not reproduce substantial content commercially except as permitted by law or written permission.",
    ], nums)

    add_heading(doc, "5. Intellectual property", 1)
    add_para(doc, "Heutrix or its licensors own the website and its content, branding, methods, graphics and downloadable materials, excluding third-party content. Heutrix grants a limited, revocable, non-exclusive licence to view the website and use a download for the personal or internal business purpose stated with it. No ownership transfers.")

    add_heading(doc, "6. Links and third-party services", 1)
    add_para(doc, "The website may link to booking, form, cloud, social or other third-party services. Those services are controlled by their providers and may have separate terms and privacy practices. A link does not mean Heutrix endorses every statement, security control or service of the third party.")

    add_heading(doc, "7. Availability and content changes", 1)
    add_para(doc, "Heutrix may update content and website features. It does not promise uninterrupted or error-free availability. Heutrix will not retrospectively change a signed client contract through a website update.")

    add_heading(doc, "8. Privacy, cookies and marketing", 1)
    add_para(doc, "The Heutrix Privacy Policy and relevant collection notice explain personal-information handling. Cookie and analytics choices must reflect the live configuration. Commercial electronic messages are sent only in accordance with consent and unsubscribe requirements.")

    add_heading(doc, "9. Australian Consumer Law and liability", 1)
    add_para(doc, "Nothing in these terms excludes a right, guarantee or remedy that cannot lawfully be excluded. To the extent permitted by law, Heutrix is not liable for loss caused solely by reliance on general website information instead of obtaining advice or a signed project scope, or for third-party services outside Heutrix's reasonable control.")
    add_para(doc, "Where Heutrix is liable in connection with free website content and the law permits a limitation, liability is limited to the reasonable cost of supplying the relevant content or access again. This limitation does not apply where it would be unfair, unreasonable or unlawful.")

    add_heading(doc, "10. Governing law and contact", 1)
    add_para(doc, "These terms are governed by the laws of Victoria, Australia. Use the website contact method for questions and clearly label legal or privacy enquiries.")
    save(doc, "07_Heutrix_Website_Terms_of_Use.docx")


if __name__ == "__main__":
    readiness_guide()
    client_services_agreement()
    workflow_diagnostic_order()
    general_sow()
    mutual_nda()
    project_forms_pack()
    privacy_policy()
    website_terms()
