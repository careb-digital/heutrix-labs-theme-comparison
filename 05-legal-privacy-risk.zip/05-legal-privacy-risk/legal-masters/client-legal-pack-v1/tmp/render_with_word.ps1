$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$wordDir = Join-Path $root 'Word'
$pdfDir = Join-Path $root 'PDF'
$qaDir = Join-Path $root 'QA'
$pdftoppm = 'C:\Users\CareBest\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe'

New-Item -ItemType Directory -Force -Path $pdfDir, $qaDir | Out-Null

$word = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0

    Get-ChildItem -LiteralPath $wordDir -Filter '*.docx' | Sort-Object Name | ForEach-Object {
        $doc = $null
        try {
            $doc = $word.Documents.Open($_.FullName, $false, $true)
            if ($doc.Fields.Count -gt 0) { $doc.Fields.Update() | Out-Null }
            foreach ($section in $doc.Sections) {
                foreach ($header in $section.Headers) {
                    if ($header.Exists -and $header.Range.Fields.Count -gt 0) { $header.Range.Fields.Update() | Out-Null }
                }
                foreach ($footer in $section.Footers) {
                    if ($footer.Exists -and $footer.Range.Fields.Count -gt 0) { $footer.Range.Fields.Update() | Out-Null }
                }
            }
            $doc.Repaginate()
            $pdfPath = Join-Path $pdfDir ($_.BaseName + '.pdf')
            $doc.ExportAsFixedFormat($pdfPath, 17, $false, 0, 0, 1, 9999, 0, $true, $true, 1, $true, $true, $false)
            Write-Output "PDF $pdfPath"
        }
        finally {
            if ($null -ne $doc) {
                $doc.Close(0)
                [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($doc) | Out-Null
            }
        }
    }
}
finally {
    if ($null -ne $word) {
        $word.Quit()
        [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) | Out-Null
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

Get-ChildItem -LiteralPath $pdfDir -Filter '*.pdf' | Sort-Object Name | ForEach-Object {
    $out = Join-Path $qaDir $_.BaseName
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    Get-ChildItem -LiteralPath $out -Filter 'page-*.png' -ErrorAction SilentlyContinue | Remove-Item -Force
    & $pdftoppm -png -r 150 $_.FullName (Join-Path $out 'page')
    if ($LASTEXITCODE -ne 0) { throw "pdftoppm failed for $($_.FullName)" }
    Write-Output "PNG $out"
}
