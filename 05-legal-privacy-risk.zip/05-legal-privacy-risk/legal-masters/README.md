# Legal masters

The [client legal pack v1](client-legal-pack-v1/) includes a readiness guide, services agreement, pre-rebrand Workflow Diagnostic order form, statement of work, confidentiality agreement, project-control forms, privacy materials and website terms in native and rendered formats.

Do not issue or sign these documents until business particulars, insurance, approved systems, commercial rules and legal review are recorded in the [legal review register](../review-register/LEGAL-REVIEW-REGISTER.md).

The 3 September 2026 consistency review also found unverified “Heutrix Pty Ltd” particulars and retired service descriptions in the native Word/PDF pack, including “Safe AI” and separate visibility/custom-system/build language in the general statement of work. The pack and its ZIP are pre-reconciliation drafts. Reissue both native and rendered versions with the three current product names and verified particulars before legal review and owner approval; do not amend an issued copy informally.
