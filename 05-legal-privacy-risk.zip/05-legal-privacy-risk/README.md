# Legal, privacy and risk

## Founder working guide
**Working scope:** Maintain controlled drafts and review evidence. A folder or file does not establish legal approval.

**Current sources:** Choose the relevant one.
- [Review status](review-register/LEGAL-REVIEW-REGISTER.md)
- [Legal masters](legal-masters/README.md)
- [Data standard](data-handling/DATA-HANDLING-STANDARD.md)
- [Website policies](website-policies/README.md)

**Dependencies and review:** Review affected operating areas and involve the adviser required by existing gates; coordinate public notices with Marketing/app maintenance.

**Complete when:** Versions, approval evidence and changed exports agree; missing particulars remain unresolved.

[Central folder ownership register](../01-company/founders-and-roles/ROLE-REGISTER.md#folder-ownership): Janith coordinates; folder owners unassigned. Use [changes](changes/README.md) only when a durable shared brief is needed. Routine work follows [AGENTS.md](../AGENTS.md); coordination details are [on demand](../00-control/COLLABORATION.md).
