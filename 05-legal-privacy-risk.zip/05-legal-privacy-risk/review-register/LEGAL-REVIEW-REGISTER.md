# Legal review register

| Document or clause set | Current version | Business particulars complete? | Legal reviewer | Owner approval | Effective date | Status |
|---|---|---|---|---|---|---|
| Client Services Agreement | v1 draft | No |  |  |  | Do not issue |
| Diagnostics Order Form (native file still uses “Workflow Diagnostic”) | v1 pre-reconciliation draft | No |  |  |  | Reissue, then legal review; do not issue |
| General Statement of Work (native file contains retired service descriptions) | v1 pre-reconciliation draft | No |  |  |  | Reissue, then legal review; do not issue |
| Mutual Confidentiality Agreement | v1 draft | No |  |  |  | Do not issue |
| Project Control Forms | v1 draft | No |  |  |  | Do not issue |
| Privacy Policy and Collection Notices | v1 draft | No |  |  |  | Do not publish |
| Website Terms of Use | v1 draft | No |  |  |  | Do not publish |

Legal review should cover scope and exclusions, privacy/data handling, liability limits, warranties, IP and reusable methods, acceptance, defects, change control, third-party systems, payment, suspension/termination and governing law.

Before review, reconcile every native and rendered document to the current three-product architecture, no-public-pricing rule, verified entity particulars and approved commercial/delivery rules. Rebuild the packaged ZIP only from those reconciled masters.
